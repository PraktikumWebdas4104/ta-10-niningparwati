<html>
	<head>
		<title>MVC</title>
	</head>
	<body>
		<form action="" method="POST">
			<table border="1" cellpadding="5" cellspacing="0" align="center">
				<tr align="center">
					<td>NIM</td>
					<td>:</td>
					<td><input type="text" name="nim" size="45" /></td>
				</tr>
				<tr align="center">
					<td>Nama</td>
					<td>:</td>
					<td><input type="text" name="nama" size="45"/></td>
				</tr>
				<tr align="center">
					<td>Angkatan</td>
					<td>:</td>
					<td><input type="text" name="angkatan" size="45"/></td>
				</tr>
				<tr align="center">
					<td>Fakultas</td>
					<td>:</td>
					<td><input type="text" name="fakultas" size="45"/></td>
				</tr>
				<tr align="center">
					<td>Prodi</td>
					<td>:</td>
					<td><input type="text" name="prodi" size="45"/></td>
				</tr>
				<tr>
		<td>Genre Film</td>
		<td>:</td>
		<td>
			<input type="checkbox" name="film[]" value="Horor">Horor
			<input type="checkbox" name="film[]" value="Action">Action
			<input type="checkbox" name="film[]" value="Anime">Anime
			<input type="checkbox" name="film[]" value="Thriller">Thriller
			<input type="checkbox" name="film[]" value="Animasi">Animasi
		</td>
	</tr>
	<tr>
		<td>Tempat Wisata Travelling</td>
		<td>:</td>
		<td>
			<input type="checkbox" name="travelling[]" value="Bali">Bali
			<input type="checkbox" name="travelling[]" value="Raja Ampat">Raja Ampat
			<input type="checkbox" name="travelling[]" value="Pulau Derawan">Pulau Derawan
			<input type="checkbox" name="travelling[]" value="Bangka Belitung">Bangka Belitung
			<input type="checkbox" name="travelling[]" value="Labuan Bajo">Labuan Bajo
		</td>
	</tr>
				<tr align="center">
					<td colspan="3"><input type="submit" name="submit"/></td>
				</tr>
			</table>
		</form>
	</body>
</html>
<?php
	if(isset($_POST['submit'])){ //jika button submit diklik maka panggil fungsi insert pada controller
		$main = new controller();
		$main->insert();
		//panggil controller insert
	}
?>