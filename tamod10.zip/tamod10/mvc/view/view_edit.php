<html>
	<head>
		<title>MVC</title>
	</head>
	<body>
		<form action="" method="POST">
			<table border="1" cellpadding="5" cellspacing="0" align="center">
				<tr align="center">
					<td>NIM</td>
					<td>:</td>
					<td><input type="text" name="nim" value="<?=$row[0]?>" size="45" readonly /></td>
				</tr>
				<tr align="center">
					<td>Nama</td>
					<td>:</td>
					<td><input type="text" name="nama" value="<?=$row[1]?>" size="45"/></td>
				</tr>
				<tr align="center">
					<td>Angkatan</td>
					<td>:</td>
					<td><input type="text" name="angkatan" value="<?=$row[2]?>" size="45"/></td>
				</tr>
				<tr align="center">
					<td>Fakultas</td>
					<td>:</td>
					<td><input type="text" name="fakultas" value="<?=$row[3]?>" size="45"/></td>
				</tr>
				<tr align="center">
					<td>Prodi</td>
					<td>:</td>
					<td><input type="text" name="prodi" value="<?=$row[4]?>" size="45"/></td>
				</tr>
				<tr align="center">
					<td>Genre Film</td>
					<?php $film = explode(',', $row[5]); ?>
					<td>:</td>
					<td>
						<input type="checkbox" name="film[]" value="Horor" <?php if (in_array('Horror', $film)) {
							echo "checked=checked";} ?>>Horor
						<input type="checkbox" name="film[]" value="Action" <?php if (in_array('Action', $film)) {
							echo "checked=checked";} ?>>Action
						<input type="checkbox" name="film[]" value="Anime" <?php if (in_array('Anime', $film)) {
							echo "checked=checked";} ?>>Anime
						<input type="checkbox" name="film[]" value="Thriller" <?php if (in_array('Thriller', $film)) {
							echo "checked=checked";} ?>>Thriller
						<input type="checkbox" name="film[]" value="Animasi" <?php if (in_array('Animasi', $film)) {
							echo "checked=checked";} ?>>Animasi
					</td>
				</tr>
				<tr align="center">
					<td>Travelling</td>
					<?php $travelling = explode(',', $row[5]); ?>
					<td>:</td>
					<td>
						<input type="checkbox" name="travelling[]" value="Bali" <?php if (in_array('Bali', $travelling)) {
							echo "checked=checked";} ?>>Bali
						<input type="checkbox" name="travelling[]" value="Raja Ampat" <?php if (in_array('Raja Ampat', $travelling)) {
							echo "checked=checked";} ?>>Raja Ampat
						<input type="checkbox" name="travelling[]" value="Pulau Derawan" <?php if (in_array('Pulau Derawan', $travelling)) {
							echo "checked=checked";} ?>>Pulau Derawan
						<input type="checkbox" name="travelling[]" value="Bangka Belitung" <?php if (in_array('Bangka Belitung', $travelling)) {
							echo "checked=checked";} ?>>Bangka Belitung
						<input type="checkbox" name="travelling[]" value="Labuan Bajo" <?php if (in_array('Labuan Bajo', $travelling)) {
							echo "checked=checked";} ?>>Labuan Bajo
					</td>
				</tr>
				<tr align="center">
					<td colspan="3"><input type="submit" name="submit"/></td>
				</tr>
			</table>
		</form>
	</body>
</html>
<?php
	if(isset($_POST['submit'])){ //jika button submit diklik maka panggil fungsi update pada controller
		$main = new controller();
		$main->update();
		//panggil controller update
	}
?>